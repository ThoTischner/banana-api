<?php

    namespace BananaService\Model;

    interface Exportable extends \BananaService\Essentials\Model\Exportable {
        // This file has been automatically decoupled by prophet. Do not edit this.
    }