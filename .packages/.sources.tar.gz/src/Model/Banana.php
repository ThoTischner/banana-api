<?php

    namespace BananaService\Model;

    class Banana extends \BananaService\Essentials\Model\Banana {
        // This file has been automatically decoupled by prophet. Do not edit this.
    }